# Simple Accounting Management System

A beginner-friendly desktop accounting application built with Python, Tkinter, and SQLite.

## Features

- Chart of Accounts
- General Journal with debit/credit lines
- General Ledger
- Trial Balance
- Balance Sheet summary
- SQLite database storage

## Important deployment note

This is a **desktop GUI application**. GitHub can host its source code, but GitHub Pages cannot run the Tkinter application in a browser. To use the software, download the repository and run it on a computer with Python and Tkinter installed. To make it available in a browser, the interface must be converted to a web application.

## Requirements

- Python 3.10 or newer recommended
- Tkinter (included with most standard Windows Python installations)
- SQLite (included with Python)

No third-party Python packages are required by the current source code.

## Run on Windows

1. Install Python from https://www.python.org/downloads/
2. During installation, select **Add Python to PATH**.
3. Download this repository as a ZIP and extract it.
4. Open the extracted folder.
5. Double-click `run_windows.bat`, or open Command Prompt in this folder and run:

   ```bash
   python simple_accounting_software.py
   ```

The program creates `accounting.db` in the current working folder when it starts. Keep this file safe because it contains the accounting records saved by the application.

## Run on macOS or Linux

Make sure Python 3 and Tkinter are installed, then run:

```bash
python3 simple_accounting_software.py
```

On some Linux distributions, Tkinter is a separate system package (for example, `python3-tk`).

## Database and privacy

- `accounting.db` is created automatically if it does not exist.
- The database is intentionally excluded from Git by `.gitignore` so personal financial records are not accidentally published.
- Back up the database regularly.
- Do not commit real customer, bank, or business financial data to a public repository.

## GitHub upload

1. Sign in at https://github.com/
2. Create a repository named `Accounting-Management-System`.
3. Upload the files in this folder, including hidden files such as `.gitignore` and `.github/workflows/python-check.yml`.
4. Commit the changes.

GitHub Actions runs a basic Python syntax compilation check whenever code is pushed. This checks syntax; it does not replace testing the graphical app on your own computer.

## Project structure

```text
Accounting-Management-System/
├── .github/
│   └── workflows/
│       └── python-check.yml
├── .gitignore
├── LICENSE
├── README.md
├── requirements.txt
├── run_windows.bat
└── simple_accounting_software.py
```

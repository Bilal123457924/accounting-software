@echo off
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 (
    echo Python was not found. Install Python from https://www.python.org/downloads/
    echo During installation, select "Add Python to PATH".
    pause
    exit /b 1
)
python simple_accounting_software.py
if errorlevel 1 (
    echo.
    echo The program exited with an error. Read the message above.
    pause
)
